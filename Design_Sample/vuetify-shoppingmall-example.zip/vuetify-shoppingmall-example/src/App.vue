<template>
  <v-app>
    <v-app-bar
      app
      color="grey lighten-5"
    >
      <v-toolbar-title color="deep-purple">나비마켓</v-toolbar-title>
      <div class="d-flex align-center"></div>

      <v-spacer></v-spacer>
      <v-spacer></v-spacer>
      <v-spacer></v-spacer>

      <v-text-field
        hide-details
        prepend-icon="search"
        color="primary"
        single-line
      ></v-text-field>

      <v-btn text>
        <v-icon>mdi-basket-outline</v-icon>
      </v-btn>
      <v-btn text>
        <v-icon>mdi-account-outline</v-icon>
      </v-btn>
    </v-app-bar>

    <v-content>
      <router-view></router-view>
    </v-content>

    <v-footer padless>
      <v-col
        class="text-center"
        cols="12"
      >
        {{ new Date().getFullYear() }} — <strong>nabi market</strong>
      </v-col>
    </v-footer>
  </v-app>
</template>
