<template>
  <v-container>
    <h3 class="title content-title">좋아요</h3>
    <v-row no-gutters>
      <v-col
        cols="12"
        sm="12"
      >
        <ProductList></ProductList>
        <ProductList></ProductList>
        <ProductList></ProductList>
        <ProductList></ProductList>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import ProductList from '@/components/ProductList'

export default {
  name: 'Home',
  components: {
    ProductList
  }
}
</script>

<style>
  .content-title {
    margin-top: 30px;
    margin-bottom: 10px;
  }
</style>
