<template>
  <div>
    <v-container>
    <DetailCarousels></DetailCarousels>
      <v-list two-line>
        <v-list-item>
          <v-list-item-avatar>
          <v-avatar color="red">
            <span class="white--text headline">사</span>
          </v-avatar>
<!--            <v-img src="https://cdn.vuetifyjs.com/images/john.png"></v-img>-->
          </v-list-item-avatar>
          <v-list-item-content>
            <v-list-item-title>사고 파는집</v-list-item-title>
            <v-list-item-subtitle>경기도 군포시 군포2동</v-list-item-subtitle>
          </v-list-item-content>
          <v-list-item-action>
            <v-btn icon>
              <v-icon>mdi-heart</v-icon>
            </v-btn>
          </v-list-item-action>
        </v-list-item>
      </v-list>
      <v-list-item>
        <v-list-item-content>
          <v-list-item-title class="display-1">오프화이트 맨투맨</v-list-item-title>
          <v-list-item-subtitle>남성의류 | 1일전</v-list-item-subtitle>
        </v-list-item-content>
      </v-list-item>
      <v-list-item two-line>
        <v-list-item-content>
          <v-list-item-title><v-icon small>mdi-currency-usd</v-icon> 가격</v-list-item-title>
          <v-list-item-subtitle>300,0000원</v-list-item-subtitle>
        </v-list-item-content>
      </v-list-item>
      <v-list-item two-line>
        <v-list-item-content>
          <v-list-item-title><v-icon small>mdi-order-bool-descending</v-icon> 상품설명</v-list-item-title>
          <v-list-item-subtitle>오프화이트 맨투맨 하자 없는거 s사이즈파정입니다 상태 좋고요 직거래 당정이에요쿨거래시 택포 됩니다 연락주새요
            교신안함 문의하지마셈 ㅎㅎ 환불도 안됩니다 !!</v-list-item-subtitle>
        </v-list-item-content>
      </v-list-item>
      <v-list-item two-line>
        <v-list-item-content>
          <v-list-item-title><v-icon small>mdi-eye</v-icon> 조회수</v-list-item-title>
          <v-list-item-subtitle>110</v-list-item-subtitle>
        </v-list-item-content>
      </v-list-item>

      <header class="title content-title">유사한 상품</header>
      <v-row no-gutters>
        <v-col
          cols="12"
          sm="4"
        >
          <ProductCard/>
        </v-col>
        <v-col
          cols="12"
          sm="4"
        >
          <ProductCard/>
        </v-col>
        <v-col
          cols="12"
          sm="4"
        >
          <ProductCard/>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import DetailCarousels from '@/components/DetailCarousels'
import ProductCard from '@/components/ProductCard'

export default {
  name: 'Home',
  components: {
    DetailCarousels,
    ProductCard
  }
}
</script>
