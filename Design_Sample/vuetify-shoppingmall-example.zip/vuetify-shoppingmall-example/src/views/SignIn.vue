<template>
  <v-layout row class="text-xs-center bg-content">
    <v-container class="text-xs-center" >
      <v-layout class="minHeightExample" row child-flex justify-center align-center wrap>
        <v-flex class="login-box" fill-height>
          <v-card class="pa-10" outlined>
            <v-card-title class="sign-title text-center">
              <h4>판매자 로그인</h4>
            </v-card-title>
            <v-form>
              <v-text-field name="Email" label="Email"></v-text-field>
              <v-text-field name="Password" label="Password" type="password"></v-text-field>
              <v-card-actions>
                <v-row align="center">
                  <v-col cols="12" sm="12">
                    <div class="text-center">
                      <div class="my-4">
                        <v-btn large block color="primary">Login</v-btn>
                      </div>
                      <div>
                        <v-btn primary large block>Sign Up</v-btn>
                      </div>
                    </div>
                  </v-col>
                </v-row>
              </v-card-actions>
            </v-form>
          </v-card>
        </v-flex>
      </v-layout>
    </v-container>
  </v-layout>
</template>

<style>
  .bg-content {
    background-image: url('https://cdn.vuetifyjs.com/images/backgrounds/vbanner.jpg');
    background-position: center;
    background-size: cover;
  }
  .minHeightExample{
    min-height:calc(100vh - 136px);
  }
  .login-box {
    max-width: 500px;
  }
  .login-box .sign-title {
    display: block;
  }
</style>
