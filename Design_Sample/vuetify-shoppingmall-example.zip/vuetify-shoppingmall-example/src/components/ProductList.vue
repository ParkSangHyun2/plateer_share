<template>
  <v-card
    class="mx-auto my-4"
    max-width="100%"
    outlined
  >
    <v-list-item three-line>
      <v-list-item-avatar
        tile
        size="100"
      >
        <v-img src="../assets/sample01.png"></v-img>
      </v-list-item-avatar>
      <v-list-item-content>
        <v-list-item-title class="headline mb-1">오프화이트 맨투맨 <span class="subtitle-2 sub-info">남성의류 | 1일전</span></v-list-item-title>
        <v-list-item-subtitle><v-icon small>mdi-map-marker-radius-outline</v-icon> 경기도 군포시 군포2동</v-list-item-subtitle>
        <v-list-item-subtitle><v-icon small>mdi-currency-usd</v-icon> 300,0000원</v-list-item-subtitle>
        <v-list-item-subtitle><v-icon small>mdi-purse-outline</v-icon> 판매중</v-list-item-subtitle>
      </v-list-item-content>
    </v-list-item>

    <v-card-actions class="action-del">
      <v-btn icon><v-icon small>mdi-trash-can-outline</v-icon></v-btn>
    </v-card-actions>
  </v-card>
</template>
<style>
  .action-del {
    position: absolute;
    right: 0;
    top: 0;
  }
  .sub-info {
    color: #777;
  }
</style>
