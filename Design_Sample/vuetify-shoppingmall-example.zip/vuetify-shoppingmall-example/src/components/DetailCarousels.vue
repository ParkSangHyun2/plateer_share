<template>
  <v-carousel>
    <v-carousel-item
      v-for="(item,i) in items"
      :key="i"
      :src="item.src"
      reverse-transition="fade-transition"
      transition="fade-transition"
    ></v-carousel-item>
  </v-carousel>
</template>

<script>
export default {
  data () {
    return {
      items: [
        {
          src: 'https://view01.wemep.co.kr/wmp-product/8/645/425866458/pm_qcn0twnr7aek.jpg?1576224149'
        },
        {
          src: 'http://kiss5481.esellersimg.co.kr/OFF-WHITE/OMBA035S190030061020_mtm_black_1000_1.jpg'
        },
        {
          src: 'http://kiss5481.esellersimg.co.kr/OFF-WHITE/OMBA035S190030061020_mtm_black_1000_1.jpg'
        },
        {
          src: 'http://kiss5481.esellersimg.co.kr/OFF-WHITE/OMBA035S190030061020_mtm_black_1000_1.jpg'
        }
      ]
    }
  }
}
</script>
