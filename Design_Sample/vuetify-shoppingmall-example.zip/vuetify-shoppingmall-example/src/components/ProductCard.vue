<template>
  <v-card
    :loading="loading"
    class="mx-auto my-4"
    max-width="374"
  >
    <v-img
      height="250"
      src="../assets/sample01.png"
    ></v-img>

    <v-card-title>오프화이트 맨투맨</v-card-title>

    <v-card-text>
      <div class="my-2 title">
        300,000원
      </div>
      <v-row
        align="center"
        class="mx-0"
      >
        <v-icon small>mdi-heart</v-icon>
        <div class="grey--text ml-1">30</div>
      </v-row>
      <div class="my-2 subtitle-1">
        경기도 군포시 군포2동
      </div>
    </v-card-text>

    <v-card-actions justify="end">
      <v-btn
        block
        color="primary"
        text
      >
        구매하기
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  name: 'ProductCard'
}
</script>
